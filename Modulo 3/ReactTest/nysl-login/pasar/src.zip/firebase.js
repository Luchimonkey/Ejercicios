export default {
    apiKey: 'AIzaSyA2EK7I2u7zIUJB8AUqI7zbDSl5flJ0zoc',
    authDomain: 'nysl-app-team5.firebaseapp.com',
    databaseURL: 'https://nysl-app-team5.firebaseio.com',
    projectId: 'nysl-app-team5',
    storageBucket: 'nysl-app-team5.appspot.com',
    messagingSenderId: '189630656816',
    appId: '1:189630656816:web:4ca891faaa9c27b5e8d8f5',
    measurementId: 'G-Y98PVDH3LF'
}

// apiKey: "AIzaSyDRWmuxaott11ARPzHwrxz2Uv_1ItZsJYI",
// authDomain: "login-85cba.firebaseapp.com",
// databaseURL: "https://login-85cba.firebaseio.com",
// projectId: "login-85cba",
// storageBucket: "login-85cba.appspot.com",
// messagingSenderId: "918542533523",
// appId: "1:918542533523:web:af0e542c8703f481e2de66",
// measurementId: "G-3FZH8CX950"